package atividade;

import br.com.fiap.healthtrack.usuario.Usuario;

/*Classe com m�todo MAIN para executar;
 * @author Luis Gustavo Ullmann
 * @version 1.8
 * */

public class Teste {
	public static void main(String[] args) {
		Usuario user = new Usuario();
		user.dadoUser();
		user.imc();
	}
}
