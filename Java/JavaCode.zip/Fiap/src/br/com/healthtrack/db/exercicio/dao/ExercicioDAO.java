package br.com.healthtrack.db.exercicio.dao;

public interface ExercicioDAO {
	
	
}
