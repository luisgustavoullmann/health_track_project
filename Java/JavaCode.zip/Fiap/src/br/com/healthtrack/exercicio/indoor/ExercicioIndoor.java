package br.com.healthtrack.exercicio.indoor;

import br.com.healthtrack.exercicio.Exercicio;

public class ExercicioIndoor extends Exercicio {
	@Override
	public void infoEx() {
		
	}

	@Override
	public String getTipo() {
		// TODO Auto-generated method stub
		return null;
	}
}
