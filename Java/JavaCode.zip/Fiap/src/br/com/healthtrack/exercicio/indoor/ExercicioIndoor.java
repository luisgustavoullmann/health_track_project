package br.com.healthtrack.exercicio.indoor;

import br.com.healthtrack.exercicio.Exercicio;

public class ExercicioIndoor extends Exercicio {
	@Override
	public void infoEx() {
		
	}
}
