package br.com.healthtrack.exercicio.indoor;

public class Musculacao extends ExercicioIndoor {
	@Override
	public void infoEx() {
		
	}
}
