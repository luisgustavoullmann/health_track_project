package br.com.healthtrack.oracle.dieta.dao;

public interface DietDAO {

}
