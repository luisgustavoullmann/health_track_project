package br.com.healthtrack.pressaoarterial.dao;

public class PresArtDAO {
	
}
