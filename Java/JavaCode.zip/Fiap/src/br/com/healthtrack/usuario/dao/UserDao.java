package br.com.healthtrack.usuario.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;

import br.com.fiap.healthtrack.usuario.Usuario;
import br.com.healthtrack.jdbc.CompanyDBManager;

public class UserDao {
	
	private Connection conexao;
	
	public void cadastrar(Usuario user) {
		PreparedStatement stmt = null;
		
		try {
			conexao = CompanyDBManager.obterConexao();
			String sql = "INSERT INTO T_USUARIO(CD_USUARIO, NM_USUARIO, NR_IDAIDE, NR_PESO,"
					+ " NR_ALTURA, NR_TELEFONE, NR_CPF, DS_SEXO)"
					+ " VALUES(SQ_USUARIO.NEXTVAL, ?, ?, ?, ?, ?, ?, ?, ?)";
			stmt = conexao.prepareStatement(sql);
			stmt.setInt(1, user.getCdUsuario());
			stmt.setString(2, user.getNome());
			stmt.setInt(3, user.getIdade());
			stmt.setDouble(4, user.getPeso());
			stmt.setDouble(5, user.getAltura());
			stmt.setInt(6, user.getTelefone());
			stmt.setInt(7, user.getCpf());
			stmt.setString(8, user.getSexo());
			
			
			
		}
	}//
	
}//done here
