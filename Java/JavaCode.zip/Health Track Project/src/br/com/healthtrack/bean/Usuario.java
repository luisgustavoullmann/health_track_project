package br.com.healthtrack.bean;

import java.util.*;


/* Classe que abstrai o cadastro de um Usuario e seu Endere�o
 * @author Luis Gustavo Ullmann
 * @version 1.7
 * */

public class Usuario {
	//Atributos
	private int cdUsuario;
	private String nome;
	private String email;
	private int idade;
	private int telefone;
	private int cpf;
	private String sexo;
	private Calendar nascimento;
	private Calendar cadastro;
	private String password;
	
	
	
	public Usuario(int code, String name, String email, int idade, int telefone, int cpf, String sexo, Calendar dataNasc, Calendar dataCadast, String password) {
		super();
		this.cdUsuario = code;
		this.nome = name;
		this.email = email;
		this.idade = idade;
		this.telefone = telefone;
		this.cpf = cpf;
		this.sexo = sexo;
		this.nascimento = dataNasc;
		this.cadastro = dataCadast;
		this.password = password;
		
	}
	
	public Usuario() {}
	
	
	
	//Getters and Setters
	public int getCdUsuario() {
		return cdUsuario;
	}

	public void setCdUsuario(int cdUsuario) {
		this.cdUsuario = cdUsuario;
	}
	
	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}
	
	public String getNome() {
		return nome;
	}
	
	public void setNome(String nome) {
		this.nome = nome;
	}

	public int getIdade() {
		return idade;
	}

	public void setIdade(int idade) {
		this.idade = idade;
	}

	public int getTelefone() {
		return telefone;
	}

	public void setTelefone(int telefone) {
		this.telefone = telefone;
	}

	public int getCpf() {
		return cpf;
	}

	public void setCpf(int cpf) {
		this.cpf = cpf;
	}

	public String getSexo() {
		return sexo;
	}

	public void setSexo(String sexo) {
		this.sexo = sexo;
	}

	public Calendar getNascimento() {
		return nascimento;
	}

	public void setNascimento(Calendar nascimento) {
		this.nascimento = nascimento;
	}

	public Calendar getCadastro() {
		return cadastro;
	}

	public void setCadastro(Calendar cadastro) {
		this.cadastro = cadastro;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	
}
