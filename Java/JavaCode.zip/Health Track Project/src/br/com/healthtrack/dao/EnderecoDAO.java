package br.com.healthtrack.dao;

import java.sql.*;
import java.util.*;

import br.com.healthtrack.bean.Endereco;

public interface EnderecoDAO {
	
	public void cadastrar(Endereco endereco) throws SQLException;
	
	public List<Endereco> getAll();
	
	public void atualizar(Endereco endereco) throws SQLException;
	
	public void remover(int code) throws SQLException;
	
	public Endereco searchId(int code);
	
	
}//
