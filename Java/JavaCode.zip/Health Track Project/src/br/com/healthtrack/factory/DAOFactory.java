package br.com.healthtrack.factory;

import br.com.healthtrack.dao.DietaDAO;
import br.com.healthtrack.dao.EnderecoDAO;
import br.com.healthtrack.dao.ExercicioDAO;
import br.com.healthtrack.dao.PesoDAO;
import br.com.healthtrack.dao.PresArtDAO;
import br.com.healthtrack.dao.UserDAO;
import br.com.healthtrack.db.dao.DbDietaDAO;
import br.com.healthtrack.db.dao.DbEnderecoDAO;
import br.com.healthtrack.db.dao.DbExercicioDAO;
import br.com.healthtrack.db.dao.DbPesoDAO;
import br.com.healthtrack.db.dao.DbPresArtDAO;
import br.com.healthtrack.db.dao.DbUserDAO;


public abstract class DAOFactory {
	public static DietaDAO getDietaDAO() {
		return new DbDietaDAO();
	}
	
	public static PesoDAO getPesoDAO() {
		return new DbPesoDAO();
	}
	
	public static ExercicioDAO getExercicioDAO() {
		return new DbExercicioDAO();
	}

	public static PresArtDAO getPresArtDAO() {
		return new DbPresArtDAO();
	}
	
	public static UserDAO getUserDAO() {
		return new DbUserDAO();
	}
	
	public static EnderecoDAO getEnderecoDAO() {
		return new DbEnderecoDAO();
	}
	
}