package br.com.healthtrack.sqlexception;

public class SQLException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * 
	 */
	public SQLException() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public SQLException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		
	}
	
	public SQLException(String message, Throwable cause) {
		super(message, cause);
	}
	
	public SQLException(String message) {
		super(message);
	}
	
	public SQLException(Throwable cause) {
		super(cause);
	}

}//
