package br.com.healthtrack.test;

import java.util.*;

import br.com.healthtrack.bean.Usuario;
import br.com.healthtrack.dao.UserDAO;
import br.com.healthtrack.dbexception.DBException;
import br.com.healthtrack.factory.DAOFactory;


/* Classe TestDAO
 * @author Luis Gustavo Ullmann
 * @version 1.7
 * */

public class TestDAO {
	public static void main(String[] args) {
		UserDAO dao = DAOFactory.getUserDAO();
		
		//Cadastrar usuario
		Usuario user = new Usuario(0, "Luis", "luis@gmail.com", 29, "222-222", "111.111.111-11", "Masculino", Calendar.getInstance(), Calendar.getInstance(), "123");
		
		try{
			dao.cadastrar(user);
			System.out.println("Usuario cadastrado!");
		} catch(DBException e) {
			e.printStackTrace();
		}
		
		//Buscar pelo id
		
	}
}
