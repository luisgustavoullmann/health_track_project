package br.com.healthtrack.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.com.healthtrack.dao.UserDAO;
import br.com.healthtrack.dbexception.DBException;
import br.com.healthtrack.factory.DAOFactory;

/**
 * Servlet implementation class CadastroServlet
 */
@WebServlet("/cadastro")
public class CadastroServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	
	private UserDAO user;
	
	
	@Override
	public void init() throws ServletException {
		super.init();
		user = DAOFactory.getUserDAO();
	}
       
    	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			String nome = request.getParameter("name");
			String sobrenome = request.getParameter("lastname");
			String email = request.getParameter("email");
			String tel = request.getParameter("telefone"); //incluir na cadastro.jsp
			String cpf = request.getParameter("cpf");//inlcuir na cadastro.jsp
			String sexo = request.getParameter("");//como incluir um checkbox?
			/*
			stmt.setString(8, user.getSexo());
			java.sql.Date dataNascimento = new java.sql.Date(user.getNascimento().getTimeInMillis());
			stmt.setDate(9, dataNascimento);
			java.sql.Date dataCadastro = new java.sql.Date(user.getCadastro().getTimeInMillis());
			stmt.setDate(10, dataCadastro);
			stmt.setString(11, user.getPassword());*/
			
		} catch (DBException db) {
			db.printStackTrace();
			request.setAttribute("erro", "Erro ao cadastrar!");
		} catch (Exception e) {
			e.printStackTrace();
			request.setAttribute("erro", "Por favor, valide os dados");
		}
		
		
	}

}
